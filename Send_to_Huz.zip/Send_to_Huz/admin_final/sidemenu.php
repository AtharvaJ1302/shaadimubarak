<!-- <div class="side-menu">
        <div class="brand-name">
            <h1>Shaadi Mubarak</h1>
        </div>
        <ul>
            <li><img src="assets/img/dashboard (2).png" alt="">&nbsp; <span>Dashboard</span> </li>
            <li><img src="assets/img/orders.png" alt="">&nbsp;<span>Orders</span> </li>
            <li><img src="assets/img/wishlist.png" alt="">&nbsp;<span>Wishlist</span> </li>
            <li><img src="assets/img/helpcenter.png" alt="">&nbsp;<span>Help Center</span> </li>
            <li><img src="assets/img/settings.png" alt="">&nbsp;<span>Settings</span> </li>
            <li><img src="assets/img/settings.png" alt="">&nbsp;<span><a href="add_item.php" alink="#B00C46" style="color: white;">Add Item</span> </li>

            <!-- <li><img src="help-web-button.png" alt="">&nbsp; <span>Help</span></li> -->
            <!-- <li><img src="settings.png" alt="">&nbsp;<span>Settings</span> </li> -->
        </ul>
    </div>
    <div class="container"> -->