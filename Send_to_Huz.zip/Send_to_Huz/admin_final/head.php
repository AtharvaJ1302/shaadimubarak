<!-- <div class="header">
            <div class="nav">
                <div class="search">
                    <input type="text" placeholder="Search..">
                    <button type="submit"><img src="assets/img/search.png" alt=""></button>
                </div>
                <div class="user">
                    <a href="#" class="btn">Add New</a>
                    <img src="assets/img/notifications.png" alt="">
                    <div class="img-case">
                        <img src="assets/img/user.png" alt="">
                    </div>
                </div>
            </div>
        </div> -->