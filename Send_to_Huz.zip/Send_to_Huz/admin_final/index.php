<?php include ('header.php'); ?>
<?php include('content.php'); ?>